﻿using System;
namespace MyTunes.Shared
{
	public class MyClass
	{
		public MyClass()
		{
		}
	}
}
