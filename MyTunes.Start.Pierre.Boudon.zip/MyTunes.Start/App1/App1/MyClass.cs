﻿using System;

namespace App1
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

