﻿using System;

namespace App2
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

